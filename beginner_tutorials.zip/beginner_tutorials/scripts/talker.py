#!/usr/bin/env python

# import rospy
# import std_msgs.msg as msg
# from sensor_msgs.msg import PointCloud2
# import sensor_msgs.point_cloud2 as pcl2
# from sensor_msgs.msg import PointField
# import open3d as o3d
# import torch as t
# import numpy as np
# import copy


# def publishPcd():
#     pub = rospy.Publisher("/Predicted_Point_Cloud", PointCloud2, queue_size=10)
#     rospy.init_node('talker', anonymous=True) # defining the ros node - publish node 
#     rate = rospy.Rate(10) # 10hz # fequency at which the publishing occurs

#     fields = [PointField('x', 0,  PointField.FLOAT32, 1),
#                 PointField('y', 4,  PointField.FLOAT32, 1),
#                 PointField('z', 8,  PointField.FLOAT32, 1),
#                 PointField('r', 12, PointField.FLOAT32, 1),
#                 PointField('g', 16, PointField.FLOAT32, 1),
#                 PointField('b', 20, PointField.FLOAT32, 1)
#                 ]

#     publishers = []

#     try:
#         while not rospy.is_shutdown():

#             # create pcd predicted
#             pcd_predicted = o3d.geometry.PointCloud()

#             pcd_predicted = o3d.io.read_point_cloud("/home/alex/Documents/pcd_test.pcd")
            
#             points = np.asarray(pcd_predicted.points)

#             if (points.size != 0):
#                 print("Afisat")
#                 header = msg.Header()
#                 header.stamp = rospy.Time.now()
#                 header.frame_id = 'camera_rgb_optical_frame'      
#                 point_cloud = pcl2.create_cloud_xyz32(header, points)
                
#                 for i, pub in enumerate(publishers):
#                     pub.publish(point_cloud[i])
#                     rate.sleep()


#     except rospy.ROSInterruptException:
#             exit()
    

# if __name__ == "__main__":
#     publishPcd()
    
#!/home/alex/RGCNN_tensorflow/bin/python

import struct
from subprocess import call

from matplotlib.pyplot import axis
import rospy
import std_msgs.msg as msg
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pcl2
from sensor_msgs.msg import PointField
import ctypes
import os
import numpy as np
from numpy.random import default_rng
import sys
np.random.seed(0)
import open3d as o3d
import torch as t

def talker():
    rospy.init_node('talker', anonymous=True) 
    pub = rospy.Publisher("/Pulbisher_Point_Cloud", PointCloud2, queue_size=10)

    rospy.sleep(1.)
    
    while not rospy.is_shutdown():
        pcd = o3d.geometry.PointCloud()
        pcd = o3d.io.read_point_cloud("/home/alex/PoinTr/data_pcd/pcd_prediction.pcd")

        points = np.asarray(pcd.points)

        pnts = np.float32(points)

        header = msg.Header()
        header.stamp = rospy.Time.now()
        header.frame_id = 'camera_rgb_optical_frame'

        message = pcl2.create_cloud_xyz32(header, pnts)

        
        pub.publish(message) # publishing 


if __name__ == "__main__":
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

    

 


 

