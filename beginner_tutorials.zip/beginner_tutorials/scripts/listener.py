#!/usr/bin/env python
import rospy
import std_msgs.msg as msg
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pcl2
import open3d as o3d
import torch as t
import numpy as np
import copy

def rotate_pcd(pcd, angle, axis):
    c = np.cos(angle)
    s = np.sin(angle)
    # x
    if axis == 0:
        R = np.array([[1 ,0 ,0],[0 ,c ,-s],[0 ,s ,c]])
    # y
    elif axis == 1:
        R = np.array([[c, 0, s],[0, 1, 0],[-s, 0, c]])
    # z
    elif axis == 2:
        R = np.array([[c, -s, 0],[s, c, 0],[0, 0, 1]])
    return pcd.rotate(R)

# def publishPcd():
#     pub = rospy.Publisher("/Predicted_Point_Cloud", PointCloud2, queue_size=10)
#     rospy.init_node('talker', anonymous=True) # defining the ros node - publish node 
#     rate = rospy.Rate(100) # 10hz # fequency at which the publishing occurs
#     try:
#         while not rospy.is_shutdown():
#             # create pcd predicted
#             pcd_predicted = o3d.geometry.PointCloud()

#             #pcd_predicted = o3d.io.read_point_cloud("/home/alex/PoinTr/data_pcd/pcd_prediction.pcd")
#             pcd_predicted = o3d.io.read_point_cloud("/home/alex/Documents/pcd_test.pcd")
#             print("Afisat")
#             #if (np.asarray(pcd_predicted.points).size != 0):
#             points = np.asarray(pcd_predicted.points)
#             header = msg.Header()
#             header.stamp = rospy.Time.now()
#             header.frame_id = 'camera_rgb_optical_frame'

#             message = pcl2.create_cloud_xyz32(header, points)

#             pub.publish(message) # publishing 
#             rate.sleep()
#     except rospy.ROSInterruptException:
#             exit()

def display_inlier_outlier(cloud, ind):
    inlier_cloud = cloud.select_by_index(ind)
    outlier_cloud = cloud.select_by_index(ind, invert=True)

    print("Showing outliers (red) and inliers (gray): ")
    outlier_cloud.paint_uniform_color([1, 0, 0])
    inlier_cloud.paint_uniform_color([0.8, 0.8, 0.8])
    o3d.visualization.draw_geometries([inlier_cloud, outlier_cloud])



def subscriberCallBack(data):

    pub = rospy.Publisher("/Pulbisher_Point_Cloud", PointCloud2, queue_size=10)

    xyz = np.array([[0, 0, 0]])
    gen = pcl2.read_points(data, skip_nans=True)
    init_data = list(gen)
    xyz = np.empty(shape=(len(init_data), 3))
    for i, x in enumerate(init_data):
            xyz[i] = np.array([x[0],x[1],x[2]])

    #####################################################################################################################################################################
    # create pcd target
    pcd_target_unfiltered = o3d.geometry.PointCloud()

    # pcd target
    if(xyz.size!=0):
        pcd_target_unfiltered.points = o3d.utility.Vector3dVector(xyz)
        pcd_target_unfiltered.paint_uniform_color([0, 1, 0]) # target green

        # center target unfiltered
        center_target = pcd_target_unfiltered.get_center()
        x_center = -center_target[0]
        y_center = -center_target[1]
        z_center = -center_target[2]
        pcd_target_unfiltered.translate(np.asarray([x_center,y_center,z_center]))

        #####################################################################################################################################################################
        #create pcd source 
        pcd_source = o3d.geometry.PointCloud()

        # pcd source 
        pcd_source = o3d.io.read_point_cloud("/home/alex/PoinTr/data_pcd/f53cba4a288db2d58e1400f6db70a939.pcd")
        pcd_source.paint_uniform_color([1, 0, 0]) # source red

        obb_source = pcd_source.get_oriented_bounding_box()
        obb_source.color = (0, 1, 0)

        # pcd source 2
        pcd_source2 = copy.deepcopy(pcd_source)
        pcd_source2.rotate(np.transpose(obb_source.R))

        obb_source2 = pcd_source2.get_oriented_bounding_box()
        obb_source2.color = (0, 1, 0)

        ########################################################################### Remove radius outlier #####################################################################################

        pcd_target, ind = pcd_target_unfiltered.remove_radius_outlier(nb_points=40,
                                                    radius=0.045)
        
        ########################################################################### Publish target #####################################################################################

        # points2 = np.asarray(pcd_target.points)
        # pnts2 = np.float32(points2)

        # header2 = msg.Header()
        # header2.stamp = rospy.Time.now()
        # header2.frame_id = 'camera_rgb_optical_frame'

        # message2 = pcl2.create_cloud_xyz32(header2, pnts2)


        # pub.publish(message2) # publishing
        ################################################################################ Downsampling #####################################################################################

        total_points = np.asarray(pcd_target.points).size
        
        #if total_points>=20000:
        #    pcd_target = pcd_target.voxel_down_sample(voxel_size=0.9)
        #else:
        #pcd_target = pcd_target.voxel_down_sample(voxel_size=0.025)
        
        ################################################################################ Normalization #####################################################################################
        
        pcd_target = rotate_pcd(pcd_target,np.pi,0)
        center_target = pcd_target.get_center()
        x_center = -center_target[0]
        y_center = -center_target[1]
        z_center = -center_target[2]
        pcd_target.translate(np.asarray([x_center,y_center,z_center]))
        pcd_target.translate(np.asarray([-0.13,0,0]))

        out_arr = np.asarray(pcd_target.points)
        min = np.min(out_arr)
        max = np.max(out_arr)
        norm_pcd = 0.716*(out_arr - min)/(max - min) - 0.358
        
        pcd_target.points = o3d.utility.Vector3dVector(norm_pcd)
        
        ################################################################################ Rotation #####################################################################################

        obb_target = pcd_target.get_oriented_bounding_box()
        obb_target.color = (0, 1, 0)

        # pcd target 2
        pcd_target2 = copy.deepcopy(pcd_target)
        pcd_target2.rotate(np.transpose(obb_target.R))
        pcd_target2.rotate(obb_source.R)

        obb_target2 = pcd_target2.get_oriented_bounding_box()
        obb_target2.color = (0, 1, 0)

        #o3d.visualization.draw_geometries([pcd_target2, pcd_source], window_name="Partial")

        pcd_target_dist1 = copy.deepcopy(pcd_target2)
        dist_1 = pcd_target_dist1.compute_point_cloud_distance(pcd_source)

        pcd_target_dist2 = copy.deepcopy(pcd_target2)
        pcd_target_dist2=rotate_pcd(pcd_target_dist2,np.pi,2)
        dist_2 = pcd_target_dist2.compute_point_cloud_distance(pcd_source)



        minim_distance_array = np.asarray([np.sum(dist_1),np.sum(dist_2)])

        if(np.min(minim_distance_array)==minim_distance_array[0]):
            o3d.io.write_point_cloud("/home/alex/PoinTr/data_pcd/pcd_input_pointtr.pcd", pcd_target_dist1, write_ascii=True, print_progress=True)
        else:
            #o3d.visualization.draw_geometries([pcd_target_dist2, pcd_source], window_name="Partial")
            o3d.io.write_point_cloud("/home/alex/PoinTr/data_pcd/pcd_input_pointtr.pcd", pcd_target_dist2, write_ascii=True, print_progress=True)
    else:
        print("Error reading point cloud!")

    
    pcd = o3d.geometry.PointCloud()
    pcd = o3d.io.read_point_cloud("/home/alex/PoinTr/data_pcd/pcd_prediction.pcd")
    pcd=rotate_pcd(pcd,-np.pi,0)
    pcd=rotate_pcd(pcd,np.pi/2,1)
    pcd.translate(np.asarray([0,0,1.08]))
    points = np.asarray(pcd.points)

    if(points.size != 0):
        pnts = np.float32(points)

        header = msg.Header()
        header.stamp = rospy.Time.now()
        header.frame_id = 'camera_rgb_optical_frame'

        message = pcl2.create_cloud_xyz32(header, pnts)

        pub.publish(message) # publishing
    
    
def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("/no_floor_out", PointCloud2, subscriberCallBack)
    rospy.spin() 

if __name__ == '__main__':
    listener()